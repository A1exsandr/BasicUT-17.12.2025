#pragma once

int CalculateWeekNumber(int year, int month, int day);